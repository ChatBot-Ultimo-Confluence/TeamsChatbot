﻿using ConfluenceChatBot.Services;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel;
using System.Text.RegularExpressions;

namespace ConfluenceChatBot.Bots
{
    public class PageProcessor
    {
        private readonly ConfluenceService _confluenceService;
        private readonly EmbeddingService _embeddingService;
        private readonly PgVectorService _pgVectorService;
        private const int MaxCharsPerSection = 500;
        private readonly IChatCompletionService _chatCompletionService;
        private readonly Kernel _kernel;

        public PageProcessor(ConfluenceService confluenceService, EmbeddingService embeddingService, PgVectorService pgVectorService,
            IChatCompletionService chatCompletionService, Kernel kernel)
        {
            _confluenceService = confluenceService;
            _embeddingService = embeddingService;
            _pgVectorService = pgVectorService;
            _chatCompletionService = chatCompletionService;
            _kernel = kernel;
        }

        public async Task ProcessPageAndInsertAsync(string pageId)
        {
            try
            {
                var (pageTitle, pageContent, version) = await _confluenceService.GetPageContentAsync(pageId);

                if (string.IsNullOrEmpty(pageContent))
                {
                    Console.WriteLine("No content fetched from Confluence.");
                    return;
                }

                await _pgVectorService.InsertEmbeddingOptimizedAsync(pageId, pageTitle, pageContent, version);
                Console.WriteLine("Page content and embedding inserted into the database.");
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"Error processing page {pageId}: {ex.Message}");
                throw;
            }
        }

        public async Task<string> SearchSemanticDataAsync(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
            return "Query is required.";

            // Get top sections from PgVector
            var results = await _pgVectorService.SearchSimilarAsync(query, 10);
            if (!results.Any())
                return "Sorry, I couldn’t find any matching information in the documents.";

            // Prepare context
            var processedSections = results
            .Select(r =>
            {
                string text = r.content.Length > MaxCharsPerSection
                    ? r.content.Substring(0, MaxCharsPerSection) + "..."
                    : r.content;
                return $"## {r.section}\n{text}";
            });

            var context = string.Join("\n\n", processedSections);

            // Chat history with a softer system message
            var chatHistory = new ChatHistory();
            chatHistory.AddSystemMessage(@"You are a helpful assistant.
                                    Use only the provided context to answer.
                                    If the context does not contain the answer, politely say you could not find that information in the documents.
                                    Do not mention 'context' directly in your answer.
                                    Keep answers short, clear, and friendly.If the context contains an example or a format, return it directly.
                                    ");

            chatHistory.AddUserMessage($@"
                                <context>
                                {context}
                                </context>

                                Question: {query}
                                ");

            // Settings
            var settings = new PromptExecutionSettings
            {
                ExtensionData = new Dictionary<string, object>
                {
                    { "temperature", 0.2 },
                    { "top_p", 0.95 },
                    { "max_tokens", 1024 },
                    { "stream", true }
                }
            };

            try
            {
                // Call Ollama
                var result = await _chatCompletionService.GetChatMessageContentAsync(chatHistory, settings, _kernel);
                string answer = result?.Content ?? "Sorry, I couldn’t find that information.";

                // Clean formatting
                answer = Regex.Replace(answer, @"```(?:plaintext)?\n?", "", RegexOptions.IgnoreCase)
                              .Replace("```", "")
                              .Trim();

                return string.IsNullOrWhiteSpace(answer)
                    ? "Sorry, I couldn’t find that information."
                    : answer;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"Semantic search failed: {ex.Message}");
                return "An error occurred during semantic search.";
            }
        }
    }
}