﻿using ConfluenceChatBot.Services;

public class ConfluenceSyncService : BackgroundService
{
    private readonly ConfluenceService _confluenceService;
    private readonly PgVectorService _pgVectorService;
    private readonly TimeSpan _interval = TimeSpan.FromMinutes(10);

    public ConfluenceSyncService(
        ConfluenceService confluenceService,
        PgVectorService pgVectorService)
    {
        _confluenceService = confluenceService;
        _pgVectorService = pgVectorService;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                int pageCount = 0;
                var pages = await _confluenceService.GetAllPagesInSpaceAsync("SB1");

                // Get all page IDs and their max versions from DB in one call
                var dbPages = await _pgVectorService.GetAllPageIdsAndVersionsAsync();
                var dbPageDict = dbPages.ToDictionary(p => p.Id, p => p.Version);

                // Keep track of page IDs in Confluence
                var confluencePageIds = new HashSet<string>();

                foreach (var page in pages)
                {
                    confluencePageIds.Add(page.Id);

                    dbPageDict.TryGetValue(page.Id, out int dbVersion);

                    if (dbVersion < page.Version)
                    {
                        // Delete older versions if exist
                        if (dbVersion > 0)
                            await _pgVectorService.DeleteOldVersionsAsync(page.Id, page.Version);

                        // Insert latest embeddings
                        await _pgVectorService.InsertEmbeddingOptimizedAsync(
                            page.Id,
                            page.Title,
                            page.Content,
                            page.Version);

                        pageCount++;
                        Console.WriteLine($"[Updated] Page: {page.Title} (v{page.Version})");
                    }
                }

                // Delete pages that are in DB but not in Confluence anymore
                var removedPageIds = dbPageDict.Keys.Except(confluencePageIds).ToHashSet();
                if (removedPageIds.Any())
                {
                    await _pgVectorService.DeletePagesByIdsAsync(removedPageIds);
                    Console.WriteLine($"Deleted embeddings for {removedPageIds.Count} removed pages.");
                }

                Console.WriteLine($"Sync completed. {pageCount} pages updated.");
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"Error updating pages: {ex.Message}");
            }

            await Task.Delay(_interval, stoppingToken);
        }
    }
}
